What you should install for compilation of tools for cygwin setup
automake
automake 1.9 
cmake
cmake-doc
cygwin32-libtool
gcc-g++
libtool
mingw-i686-libpagemaker0.0
mingw64-x86_64-gcc-g++
pwget
wget
wget-debuginfo
